
  # Khoj Analysis: Dummy Deck

  This is a code bundle for Khoj Analysis: Dummy Deck. The original project is available at https://www.figma.com/design/4NWYA1tIQuJPSE9mGHlgvU/Khoj-Analysis--Dummy-Deck.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  